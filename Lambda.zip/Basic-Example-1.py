import requests

def test1(event=None, context=None):
    r=requests.get("http://worldtimeapi.org/api/timezone/America/Chicago")
    if r.status_code == 200:
        return "It was successful"

